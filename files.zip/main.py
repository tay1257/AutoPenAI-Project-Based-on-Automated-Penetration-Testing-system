"""
AutoPenAI - Main Runner
=======================
Run this file to see the agent in action.

Usage:
  python main.py

What happens:
  1. Agent starts with a demo target (scanme.nmap.org - a legal test target)
  2. Runs through Phase 1 → 2 → 3 automatically
  3. Pauses at Phase 4 (human review)
  4. Simulates human approval
  5. Generates the final report
"""

import uuid
import sys
import os

# Add parent directory to path so imports work
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agent.brain import PenTestAgent, AgentState, ScanTarget
from tools.tool_runner import MockToolRunner


def print_banner():
    print("""
╔══════════════════════════════════════════════════════╗
║           AutoPenAI — Autonomous Pen-Test Agent       ║
║         Milan AI Week Hackathon 2026                  ║
║         Powered by Claude (Anthropic)                 ║
╚══════════════════════════════════════════════════════╝
    """)


def run_demo():
    """
    Full demo run showing all 5 phases.
    Uses MockToolRunner so no real systems are touched.
    """
    print_banner()

    # ── Step 1: Define the target ──
    # scanme.nmap.org is a legal target maintained by nmap.org
    # specifically for testing scanners. Perfect for demos!
    target = ScanTarget(
        host="scanme.nmap.org",
        scope=["scanme.nmap.org", "45.33.32.156"],  # Only test these
        consent_confirmed=True,                       # User confirmed permission
        session_id=str(uuid.uuid4())[:8]             # Short unique session ID
    )

    # ── Step 2: Create initial agent state ──
    state = AgentState(target=target)

    # ── Step 3: Create the agent with mock tools ──
    # Switch MockToolRunner → RealToolRunner for real scans
    # (only on systems you own or have permission to test!)
    runner = MockToolRunner()
    agent = PenTestAgent(tool_runner=runner)

    # ── Step 4: Run phases 1, 2, 3 automatically ──
    print("\n📋 Starting autonomous penetration test...\n")
    state = agent.run(state)

    # ── Step 5: Human review gate ──
    if state.phase == "awaiting_approval":
        print("\n" + "─"*55)
        print("⏸️  HUMAN REVIEW REQUIRED")
        print("─"*55)

        # Show what was found
        vulns = state.vuln_data.get("vulnerabilities", [])
        print(f"\n📊 Findings Summary:")
        print(f"   Open ports found  : {len(state.recon_data.get('open_ports', []))}")
        print(f"   CVEs discovered   : {len(vulns)}")

        risk = state.vuln_data.get("risk_summary", {})
        print(f"   Critical findings : {risk.get('critical', 0)}")
        print(f"   High findings     : {risk.get('high', 0)}")
        print(f"   Overall risk      : {risk.get('overall_risk', 'Unknown')}")

        print("\n⚠️  Top vulnerabilities found:")
        for v in vulns[:3]:
            print(f"   [{v['severity']:8s}] {v['cve_id']} - {v['service']}")

        # In the real web UI, this would be a button click
        # Here we simulate automatic approval for the demo
        print("\n✅ Demo: Auto-approving findings for report generation...")
        print("   (In the real UI, a human clicks 'Approve' in the dashboard)")

        # ── Step 6: Resume after approval ──
        state = agent.resume_after_approval(state)

    # ── Step 7: Print final result ──
    print("\n" + "═"*55)
    if state.phase == "complete":
        print("✅ PENETRATION TEST COMPLETE")
        print(f"   Session ID  : {state.target.session_id}")
        print(f"   Report path : {state.report_path}")
        print(f"   Actions log : {len(state.history)} steps recorded")
        print("""
📄 Report sections generated:
   1. Executive Summary
   2. Scope and Methodology
   3. Critical Findings (2 CVEs - immediate action required)
   4. High Findings (2 CVEs - fix within 7 days)
   5. Attack Path Analysis
   6. Remediation Roadmap
   7. Appendix: Raw Scan Data
        """)
    elif state.error:
        print(f"❌ AGENT STOPPED DUE TO ERROR:")
        print(f"   {state.error}")
    else:
        print(f"⚠️  Agent ended in unexpected phase: {state.phase}")

    print("═"*55)
    return state


if __name__ == "__main__":
    run_demo()
