"""
AutoPenAI - Tool Runner
=======================
This file contains the actual tools the agent can use.

Each method here matches a tool name registered in brain.py.
When Claude says "call run_recon", the agent calls self.tool_runner.run_recon()

TWO MODES:
  - Demo mode (default): returns realistic fake data so you can
    demo safely without needing real targets or nmap installed.
  - Real mode: runs actual nmap, queries real NVD API, etc.
    Only use on targets you own or have written permission to test.
"""

import json
import time
import random
import requests
from datetime import datetime


class MockToolRunner:
    """
    DEMO MODE tool runner.
    Returns realistic-looking data without touching any real systems.
    Perfect for hackathon demo and development.
    """

    def run_recon(self, params: dict) -> dict:
        """
        Simulates Phase 1: Reconnaissance.

        In real mode this would run:
          nmap -sV -sC -T4 {host}
          dig {host}
          whois {host}
          whatweb {host}

        Returns structured data about open ports, services, and technologies.
        """
        host = params["host"]
        scan_type = params.get("scan_type", "quick")

        # Simulate scan taking time
        time.sleep(1.5)

        # Realistic mock data
        return {
            "host": host,
            "scan_type": scan_type,
            "scan_time": datetime.now().isoformat(),
            "ip_address": "45.33.32.156",
            "os_guess": "Linux 4.15 (Ubuntu 18.04)",
            "open_ports": [
                {
                    "port": 22,
                    "protocol": "tcp",
                    "state": "open",
                    "service": "ssh",
                    "version": "OpenSSH 6.6.1p1",
                    "banner": "SSH-2.0-OpenSSH_6.6.1p1 Ubuntu-2ubuntu2.13"
                },
                {
                    "port": 80,
                    "protocol": "tcp",
                    "state": "open",
                    "service": "http",
                    "version": "Apache httpd 2.4.7",
                    "banner": "Apache/2.4.7 (Ubuntu)"
                },
                {
                    "port": 443,
                    "protocol": "tcp",
                    "state": "open",
                    "service": "https",
                    "version": "Apache httpd 2.4.7",
                    "tls_version": "TLSv1.2"
                },
                {
                    "port": 3306,
                    "protocol": "tcp",
                    "state": "open",
                    "service": "mysql",
                    "version": "MySQL 5.5.62",
                    "banner": "MySQL 5.5.62-0ubuntu0.14.04.1"
                }
            ],
            "dns_records": {
                "A": ["45.33.32.156"],
                "MX": [],
                "TXT": ["v=spf1 include:_spf.google.com ~all"]
            },
            "whois": {
                "registrar": "Namecheap Inc.",
                "creation_date": "2010-03-15",
                "expiry_date": "2026-03-15"
            },
            "technologies": [
                "Apache 2.4.7",
                "PHP 5.5.9",
                "Ubuntu Linux",
                "jQuery 1.11.1"
            ],
            "services_list": [
                "openssh 6.6.1p1",
                "apache 2.4.7",
                "mysql 5.5.62",
                "php 5.5.9"
            ]
        }

    def map_vulnerabilities(self, params: dict) -> dict:
        """
        Simulates Phase 2: Vulnerability Mapping.

        In real mode this would:
          1. Query NVD API: https://services.nvd.nist.gov/rest/json/cves/2.0
          2. Match each service version against known CVEs
          3. Calculate CVSS scores

        CVSS score meanings:
          9.0-10.0 = Critical   (needs immediate fix)
          7.0-8.9  = High       (fix this week)
          4.0-6.9  = Medium     (fix this month)
          0.1-3.9  = Low        (fix when possible)
        """
        services = params["services"]
        time.sleep(1.0)

        return {
            "scan_time": datetime.now().isoformat(),
            "services_checked": services,
            "total_cves_found": 4,
            "vulnerabilities": [
                {
                    "cve_id": "CVE-2021-41773",
                    "service": "apache 2.4.49",
                    "severity": "Critical",
                    "cvss_score": 9.8,
                    "description": (
                        "Path traversal and remote code execution in Apache HTTP Server 2.4.49. "
                        "Allows attacker to map URLs to files outside document root. "
                        "If CGI scripts are enabled, remote code execution is possible."
                    ),
                    "affected_version": "Apache 2.4.49",
                    "fixed_in": "Apache 2.4.50+",
                    "exploitable_remotely": True,
                    "poc_available": True,
                    "remediation": "Upgrade Apache to version 2.4.51 or later immediately."
                },
                {
                    "cve_id": "CVE-2016-6515",
                    "service": "openssh 6.6.1p1",
                    "severity": "High",
                    "cvss_score": 7.8,
                    "description": (
                        "OpenSSH through 7.2 does not limit password lengths, "
                        "allowing remote attackers to cause denial of service via "
                        "a long string in a password authentication request."
                    ),
                    "affected_version": "OpenSSH < 7.3",
                    "fixed_in": "OpenSSH 7.3+",
                    "exploitable_remotely": True,
                    "poc_available": True,
                    "remediation": "Upgrade OpenSSH to 7.3 or later."
                },
                {
                    "cve_id": "CVE-2012-2122",
                    "service": "mysql 5.5.62",
                    "severity": "High",
                    "cvss_score": 7.5,
                    "description": (
                        "Oracle MySQL 5.1.x before 5.1.63, 5.5.x before 5.5.24, "
                        "allows remote attackers to bypass authentication by "
                        "repeatedly authenticating with the same incorrect password."
                    ),
                    "affected_version": "MySQL < 5.5.24",
                    "fixed_in": "MySQL 5.5.24+",
                    "exploitable_remotely": True,
                    "poc_available": True,
                    "remediation": "Upgrade MySQL. Disable remote root login. Use strong passwords."
                },
                {
                    "cve_id": "CVE-2019-11043",
                    "service": "php 5.5.9",
                    "severity": "Critical",
                    "cvss_score": 9.8,
                    "description": (
                        "In PHP versions 7.1.x below 7.1.33, 7.2.x below 7.2.24 "
                        "and 7.3.x below 7.3.11 in certain configurations of FPM "
                        "setup it is possible to cause FPM module to write past allocated buffers "
                        "into the space allocated for FCGI protocol data, potentially leading "
                        "to a remote code execution vulnerability."
                    ),
                    "affected_version": "PHP 5.5.x",
                    "fixed_in": "PHP 7.3.11+",
                    "exploitable_remotely": True,
                    "poc_available": True,
                    "remediation": "Upgrade PHP to 7.4+ (PHP 5.5 is end-of-life and unsupported)."
                }
            ],
            "risk_summary": {
                "critical": 2,
                "high": 2,
                "medium": 0,
                "low": 0,
                "overall_risk": "Critical"
            }
        }

    def simulate_exploit(self, params: dict) -> dict:
        """
        Simulates Phase 3: Exploit Simulation (SANDBOX ONLY).

        In real mode (controlled lab environment only) this would use:
          - Metasploit Framework Python API
          - Custom proof-of-concept scripts
          - All traffic contained in isolated network namespace

        This simulation determines:
          - Is the vulnerability actually exploitable? (not all CVEs are)
          - What access level would an attacker gain?
          - What data could be accessed?
        """
        cve_ids = params["cve_ids"]
        target_host = params["target_host"]
        time.sleep(2.0)  # Simulate exploit attempts taking time

        results = []
        for cve_id in cve_ids:
            # Simulate different exploit outcomes
            if cve_id == "CVE-2021-41773":
                results.append({
                    "cve_id": cve_id,
                    "exploitable": True,
                    "exploit_type": "Remote Code Execution",
                    "access_gained": "www-data (web server user)",
                    "data_accessible": [
                        "Web application source code",
                        "Configuration files (database credentials)",
                        "User uploaded files"
                    ],
                    "lateral_movement_possible": True,
                    "sandbox_note": "SIMULATION ONLY - no real exploitation performed"
                })
            elif cve_id == "CVE-2019-11043":
                results.append({
                    "cve_id": cve_id,
                    "exploitable": True,
                    "exploit_type": "Remote Code Execution via PHP-FPM",
                    "access_gained": "www-data",
                    "data_accessible": ["PHP application files", "Session data"],
                    "lateral_movement_possible": False,
                    "sandbox_note": "SIMULATION ONLY - no real exploitation performed"
                })
            else:
                results.append({
                    "cve_id": cve_id,
                    "exploitable": False,
                    "reason": "Mitigating controls detected or version not vulnerable",
                    "sandbox_note": "SIMULATION ONLY"
                })

        return {
            "target": target_host,
            "simulation_time": datetime.now().isoformat(),
            "exploit_results": results,
            "exploitable_count": sum(1 for r in results if r.get("exploitable")),
            "critical_paths": [
                {
                    "path": "Apache RCE → Config files → Database credentials → MySQL",
                    "steps": 3,
                    "impact": "Full database compromise possible"
                }
            ],
            "sandbox_disclaimer": (
                "All exploit attempts ran in an isolated simulation environment. "
                "No real network traffic was sent to the target."
            )
        }

    def generate_report(self, params: dict) -> dict:
        """
        Simulates Phase 5: Report Generation.

        In real mode this creates a professional PDF report using:
          - ReportLab or WeasyPrint for PDF generation
          - Structured findings with CVSS scores
          - Executive summary for non-technical stakeholders
          - Technical details for security engineers
          - Remediation roadmap with priorities
        """
        session_id = params["session_id"]
        time.sleep(1.0)

        report_path = f"/tmp/autopenai_report_{session_id}.pdf"

        return {
            "success": True,
            "report_path": report_path,
            "report_id": session_id,
            "generated_at": datetime.now().isoformat(),
            "pages": 12,
            "sections": [
                "Executive Summary",
                "Scope and Methodology",
                "Findings Overview",
                "Critical Findings (2)",
                "High Findings (2)",
                "Attack Path Analysis",
                "Remediation Roadmap",
                "Appendix: Raw Scan Data"
            ],
            "risk_score": 9.2,
            "overall_rating": "Critical",
            "message": f"Report generated successfully at {report_path}"
        }


class RealToolRunner:
    """
    REAL MODE tool runner.
    Only use this on systems you own or have written permission to test.

    Requires:
      pip install python-nmap requests
      apt install nmap
    """

    def run_recon(self, params: dict) -> dict:
        """Run actual nmap scan."""
        try:
            import nmap
            nm = nmap.PortScanner()
            host = params["host"]
            args = "-sV -sC -T4 --top-ports 100" if params.get("scan_type") == "quick" else "-sV -sC -T4"
            nm.scan(host, arguments=args)

            open_ports = []
            for proto in nm[host].all_protocols():
                for port in nm[host][proto]:
                    port_data = nm[host][proto][port]
                    if port_data["state"] == "open":
                        open_ports.append({
                            "port": port,
                            "protocol": proto,
                            "state": "open",
                            "service": port_data.get("name", "unknown"),
                            "version": f"{port_data.get('product','')} {port_data.get('version','')}".strip()
                        })

            return {
                "host": host,
                "ip_address": nm[host].get("addresses", {}).get("ipv4", host),
                "open_ports": open_ports,
                "services_list": [
                    f"{p['service']} {p['version']}" for p in open_ports
                ]
            }
        except Exception as e:
            return {"error": str(e), "note": "Install python-nmap and nmap"}

    def map_vulnerabilities(self, params: dict) -> dict:
        """Query real NVD API for CVEs."""
        services = params["services"]
        vulnerabilities = []

        for service in services:
            parts = service.split()
            if len(parts) >= 2:
                keyword = f"{parts[0]} {parts[1]}"
                try:
                    resp = requests.get(
                        "https://services.nvd.nist.gov/rest/json/cves/2.0",
                        params={"keywordSearch": keyword, "resultsPerPage": 3},
                        timeout=10
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        for vuln in data.get("vulnerabilities", []):
                            cve = vuln["cve"]
                            metrics = cve.get("metrics", {})
                            cvss_data = metrics.get("cvssMetricV31", [{}])[0].get("cvssData", {})
                            vulnerabilities.append({
                                "cve_id": cve["id"],
                                "service": service,
                                "cvss_score": cvss_data.get("baseScore", 0),
                                "severity": cvss_data.get("baseSeverity", "Unknown"),
                                "description": cve.get("descriptions", [{}])[0].get("value", "")
                            })
                    time.sleep(0.6)  # NVD rate limit: max 5 req/sec without API key
                except Exception as e:
                    continue

        return {"vulnerabilities": vulnerabilities, "total_cves_found": len(vulnerabilities)}

    def simulate_exploit(self, params: dict) -> dict:
        """Exploit simulation - uses Metasploit in isolated network namespace."""
        # In production: use msfrpc client to connect to Metasploit
        # and run exploits against an isolated clone of the target
        return {"note": "Metasploit integration - requires lab environment setup"}

    def generate_report(self, params: dict) -> dict:
        """Generate real PDF report using ReportLab."""
        # In production: use ReportLab to build a structured PDF
        return {"note": "PDF generation - requires ReportLab setup"}
