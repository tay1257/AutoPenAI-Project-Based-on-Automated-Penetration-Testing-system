"""
AutoPenAI - Agent Brain
=======================
This is the AI brain of the agent. It uses Claude to:
1. Read scan results from tools
2. Decide what to do next (plan)
3. Execute the next action
4. Keep doing this until the pentest is complete

Think of it like a smart project manager who knows security:
  - You give it a target (e.g. "scanme.nmap.org")
  - It runs recon, finds vulnerabilities, simulates exploits
  - It hands you a professional report at the end
"""

import anthropic
import json
from typing import Optional
from dataclasses import dataclass, field


# ──────────────────────────────────────────────
# Data structures (like containers for our data)
# ──────────────────────────────────────────────

@dataclass
class ScanTarget:
    """Holds everything about the target we are testing."""
    host: str                          # e.g. "scanme.nmap.org" or "192.168.1.1"
    scope: list[str]                   # list of allowed IPs/domains
    consent_confirmed: bool = False    # user MUST tick a box to confirm permission
    session_id: str = ""               # unique ID for this scan session


@dataclass
class AgentState:
    """
    Tracks where the agent is in its 5-phase journey.
    The agent reads this state at every step to know what
    has already been done and what comes next.
    """
    target: ScanTarget
    phase: str = "idle"                # current phase name
    recon_data: dict = field(default_factory=dict)        # phase 1 results
    vuln_data: dict = field(default_factory=dict)         # phase 2 results
    exploit_data: dict = field(default_factory=dict)      # phase 3 results
    human_approved: bool = False       # did human approve findings?
    report_path: Optional[str] = None  # path to final PDF report
    history: list = field(default_factory=list)           # full log of every action
    error: Optional[str] = None        # any error that stopped the agent


# ──────────────────────────────────────────────
# The tools the agent can call
# (These are registered with Claude so it can
#  decide when and how to use each one)
# ──────────────────────────────────────────────

AGENT_TOOLS = [
    {
        "name": "run_recon",
        "description": (
            "Run Phase 1 reconnaissance on the target. "
            "This performs DNS lookup, WHOIS, port scanning, "
            "and technology fingerprinting. Safe - read only."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "host": {
                    "type": "string",
                    "description": "The target hostname or IP address"
                },
                "scan_type": {
                    "type": "string",
                    "enum": ["quick", "full"],
                    "description": "quick = top 100 ports, full = all 65535 ports"
                }
            },
            "required": ["host", "scan_type"]
        }
    },
    {
        "name": "map_vulnerabilities",
        "description": (
            "Run Phase 2 vulnerability mapping. "
            "Takes recon results and cross-references with the "
            "National Vulnerability Database (NVD) to find known CVEs. "
            "Assigns CVSS severity scores to each finding."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "services": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of services found in recon e.g. ['apache 2.4.49', 'openssh 7.4']"
                }
            },
            "required": ["services"]
        }
    },
    {
        "name": "simulate_exploit",
        "description": (
            "Run Phase 3 exploit simulation in a SAFE SANDBOX. "
            "This does NOT perform real exploitation. It simulates "
            "attack paths to determine exploitability and impact. "
            "Only runs on vulnerabilities already found in phase 2."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "cve_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of CVE IDs to simulate e.g. ['CVE-2021-41773']"
                },
                "target_host": {
                    "type": "string",
                    "description": "Target host (must be in approved scope)"
                }
            },
            "required": ["cve_ids", "target_host"]
        }
    },
    {
        "name": "generate_report",
        "description": (
            "Run Phase 5 report generation. "
            "Takes all findings and creates a professional PDF report "
            "with executive summary, technical details, and remediation steps."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "The session ID of this scan"
                },
                "include_executive_summary": {
                    "type": "boolean",
                    "description": "Whether to include a non-technical summary for management"
                }
            },
            "required": ["session_id"]
        }
    }
]


# ──────────────────────────────────────────────
# The Agent Brain Class
# ──────────────────────────────────────────────

class PenTestAgent:
    """
    The main AI agent.

    How it works (simple explanation):
    ------------------------------------
    1. You call agent.run(target)
    2. The agent sends a message to Claude saying:
       "You are a security tester. Here is your target. Go."
    3. Claude decides which tool to call first (run_recon)
    4. We actually run that tool and send the result back to Claude
    5. Claude reads the result and decides the next tool (map_vulnerabilities)
    6. We repeat until Claude says it's done (no more tool calls)
    7. We return the final state with the report path

    This loop of: Claude decides → we execute → Claude reads → Claude decides
    is called an "agentic loop" — the heart of any autonomous agent.
    """

    def __init__(self, tool_runner):
        """
        tool_runner: an object that has methods matching our tool names.
        We inject it here so the agent doesn't care HOW tools run,
        just that they return results. (This is called dependency injection)
        """
        self.client = anthropic.Anthropic()
        self.tool_runner = tool_runner
        self.model = "claude-sonnet-4-20250514"

    def _build_system_prompt(self, state: AgentState) -> str:
        """
        The system prompt is the agent's 'job description'.
        It tells Claude exactly what role it plays and what rules it must follow.
        """
        return f"""You are AutoPenAI, an expert autonomous penetration testing agent.

Your job is to systematically test the security of a target system by running
through exactly 5 phases in order:

  Phase 1 → Reconnaissance      (run_recon tool)
  Phase 2 → Vulnerability mapping (map_vulnerabilities tool)
  Phase 3 → Exploit simulation   (simulate_exploit tool)
  Phase 4 → Human review         (you STOP and wait - do NOT call tools)
  Phase 5 → Report generation    (generate_report tool - ONLY after human approves)

CURRENT SESSION:
  Target host   : {state.target.host}
  Approved scope: {', '.join(state.target.scope)}
  Session ID    : {state.target.session_id}
  Human approved: {state.human_approved}

STRICT RULES (never break these):
  1. NEVER test any host not in the approved scope list.
  2. NEVER perform real exploitation - simulation only.
  3. Run phases IN ORDER. Do not skip phases.
  4. After Phase 3, stop and tell the user to review findings.
  5. Only run generate_report if human_approved is True.
  6. Always explain what you found before moving to the next phase.

You are professional, precise, and security-focused. Every finding must include
its severity (Critical/High/Medium/Low) and a remediation recommendation."""

    def _build_user_message(self, state: AgentState) -> str:
        """
        Tells the agent what the current state is so it knows
        what has already been done and what to do next.
        """
        if state.phase == "idle":
            return (
                f"Begin the penetration test on target: {state.target.host}\n"
                f"Start with Phase 1 - Reconnaissance. Use scan_type='quick' first."
            )
        elif state.phase == "awaiting_approval":
            if state.human_approved:
                return (
                    "The human reviewer has approved the findings. "
                    "Please proceed to Phase 5 and generate the final report. "
                    f"Session ID: {state.target.session_id}"
                )
            else:
                return (
                    "Waiting for human approval before generating the report. "
                    "Summarize all findings found so far for the reviewer."
                )
        else:
            return f"Continue from phase: {state.phase}"

    def _execute_tool(self, tool_name: str, tool_input: dict, state: AgentState) -> str:
        """
        When Claude asks to call a tool, this method:
        1. Checks the tool is safe to run (scope check)
        2. Calls the real tool function
        3. Updates the agent state with results
        4. Returns the result as a string for Claude to read

        Simple analogy: Claude is the manager, this is the worker
        who actually does the job and reports back.
        """

        # Safety check - never run tools on out-of-scope hosts
        if "target_host" in tool_input:
            if tool_input["target_host"] not in state.target.scope:
                return json.dumps({
                    "error": "SCOPE VIOLATION - target not in approved scope",
                    "requested": tool_input["target_host"],
                    "allowed": state.target.scope
                })

        print(f"\n  🔧 Executing tool: {tool_name}")
        print(f"     Input: {json.dumps(tool_input, indent=6)}")

        try:
            # Call the matching method on our tool runner
            result = getattr(self.tool_runner, tool_name)(tool_input)

            # Update state based on which tool just ran
            if tool_name == "run_recon":
                state.phase = "recon_complete"
                state.recon_data = result
            elif tool_name == "map_vulnerabilities":
                state.phase = "vuln_complete"
                state.vuln_data = result
            elif tool_name == "simulate_exploit":
                state.phase = "awaiting_approval"
                state.exploit_data = result
            elif tool_name == "generate_report":
                state.phase = "complete"
                state.report_path = result.get("report_path")

            # Log every action for audit trail
            state.history.append({
                "tool": tool_name,
                "input": tool_input,
                "result_summary": str(result)[:200]  # truncate for log
            })

            print(f"  ✅ Tool completed: {tool_name}")
            return json.dumps(result)

        except Exception as e:
            error_msg = f"Tool execution failed: {str(e)}"
            state.error = error_msg
            print(f"  ❌ {error_msg}")
            return json.dumps({"error": error_msg})

    def run(self, state: AgentState, max_iterations: int = 10) -> AgentState:
        """
        THE MAIN AGENTIC LOOP
        =====================
        This is where the magic happens. We keep looping:
          1. Send messages + current state to Claude
          2. Claude responds with either:
             a. A tool call → we run it, add result, loop again
             b. A text response → we print it, keep looping if not done
             c. stop_reason="end_turn" with no tools → we're done

        max_iterations: safety limit so agent can't loop forever
        """

        if not state.target.consent_confirmed:
            state.error = "Cannot start: user has not confirmed consent"
            return state

        print(f"\n{'='*55}")
        print(f"  AutoPenAI Agent Starting")
        print(f"  Target : {state.target.host}")
        print(f"  Session: {state.target.session_id}")
        print(f"{'='*55}")

        # Start conversation history with the user's first message
        messages = [
            {"role": "user", "content": self._build_user_message(state)}
        ]

        for iteration in range(max_iterations):
            print(f"\n[Iteration {iteration + 1}] Phase: {state.phase}")

            # ── Send to Claude ──
            response = self.client.messages.create(
                model=self.model,
                max_tokens=4096,
                system=self._build_system_prompt(state),
                tools=AGENT_TOOLS,
                messages=messages
            )

            print(f"  Stop reason: {response.stop_reason}")

            # ── Add Claude's response to conversation history ──
            messages.append({
                "role": "assistant",
                "content": response.content
            })

            # ── Process each content block in Claude's response ──
            tool_results = []
            has_tool_calls = False

            for block in response.content:

                if block.type == "text":
                    # Claude is explaining something - print it
                    print(f"\n  💬 Agent: {block.text[:300]}...")

                elif block.type == "tool_use":
                    # Claude wants to call a tool - execute it
                    has_tool_calls = True
                    result_str = self._execute_tool(
                        block.name, block.input, state
                    )
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result_str
                    })

            # ── If there were tool calls, add results and loop again ──
            if tool_results:
                messages.append({
                    "role": "user",
                    "content": tool_results
                })
                continue

            # ── If Claude stopped without tool calls ──
            if response.stop_reason == "end_turn":
                # Check if we're at human approval gate
                if state.phase == "awaiting_approval" and not state.human_approved:
                    print("\n  ⏸️  Agent paused - waiting for human review")
                    break
                # Check if fully complete
                elif state.phase == "complete":
                    print("\n  🎉 Agent completed successfully!")
                    break
                else:
                    # Agent finished a phase but didn't call the next tool yet
                    # Nudge it to continue
                    messages.append({
                        "role": "user",
                        "content": "Continue to the next phase."
                    })

        return state

    def resume_after_approval(self, state: AgentState) -> AgentState:
        """
        Called after the human reviews and approves findings.
        Sets the approval flag and re-runs the agent to generate the report.
        """
        state.human_approved = True
        state.phase = "awaiting_approval"
        return self.run(state)
